export const Page404 = () => {
  return <h1>Page404</h1>;
};
