const User = () => {
  return <h1>user</h1>;
};
export default User;
